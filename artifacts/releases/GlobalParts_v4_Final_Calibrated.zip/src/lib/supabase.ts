import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Faltando variáveis de ambiente do Supabase. Verifique seu arquivo .env');
}

export const supabase = createClient(supabaseUrl || '', supabaseAnonKey || '');
